module.exports = {
  apps: [
    {
      name: 'tvapp-backend',
      script: 'src/app.js',
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
};


